# Parent Teacher Dashboard
The PT Dashboard, as im formally calling it, was a small project I had for small daycare businesses to use to keep track of various aspects of their day to day duties.

*At this time Im currently working on function over style and design.*

**This app includes:**
- Logins for Parents and Teachers 
- Daily Student Reports
- Create Upcoming Events
- Incident Reporting(WIP)
- Private Messaging System(WIP)
- Search function

Parents and Teachers will have their own seperate Dashboard where they will be able to see options that fit their needs.  
For instance Parents will have the ability to(*WIP*):

- View/Edit their child's info
- View/Edit Their Own Info
- Modify their Approved Pickup list
- View their child's Daily Reports
- View any incidents invloving their child
- View upcoming events and announcements

### **Test Logins**
> Username: teacher
> Password: password
