# Dashboard-Admin-Template-HTML-CSS-JS
Admin Dashboard is a fully responsive  Bootstrap 5 admin dashboard template. It is built with Bootstrap 5  framework, HTML5, CSS, and JQuery.
